//Header indhold

//Logo, css og router import
import logo from "./../img/logocph.png";
import { Outlet, NavLink } from "react-router-dom";
import "./../css/TheHeader.css";

export default function TheHeader() {
  return (
    <header>
      <div id="headerBox">

        {/* Logo */}
        <div>
         <a href="Nybooking"><img id="logo" src={logo} alt="CphBusiness Logo" /></a>
        </div>

        {/* Navbar links */}
        <div id="headerLinks">

          {/* Nybooking link */}
          <NavLink
            to="Nybooking"
            activeclassname="active"
            className="headerbutton"
          >
            Oversigt
          </NavLink>

          {/* Mine bookinger link */}
          <NavLink
            to="Minebookinger"
            activeclassname="active"
            className="headerbutton"
          >
            Mine bookinger
          </NavLink>

          {/* Login side link */}
          <NavLink 
          to="/" 
          activeclassname="active" 
          className="headerbutton"
          >
            Log ind
          </NavLink>
        </div>

        {/* Outlet */}
        <Outlet />

      </div>
    </header>
  );
}
