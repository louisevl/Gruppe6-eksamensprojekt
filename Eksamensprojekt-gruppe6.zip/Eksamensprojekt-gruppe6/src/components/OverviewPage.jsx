//Samler funktionerne fra kalenderen (OverviewCalendar), "Ny booking" knappen og oversigten (OverviewSortBooking, der snakker sammen med OverviewBooking) og viser det i browseren

//Import
import OverviewSortBooking from "./OverviewSortBooking";
import OverviewCalendar from "./OverviewCalendar";
import NewBooking from "./NewBooking";
import { useState } from "react";
import "./../css/OverviewCalendar.css";
import "./../css/BookingModal.css";

export default function OverviewPage() {
  const [formatDate, setFormatDate] = useState();
  return (
    <div className="App">
      <div className="flex">
        {/* Viser output fra componentet "NewBooking" */}
        <NewBooking />
      </div>
      <div className="flex">
        {/* Viser output fra component "OverviewCalender" og eksporterer/deler setFormatDate til/med OverviewCalender */}
        <OverviewCalendar setFormatDate={setFormatDate}/>
        {/* Viser output fra component "OverviewsortBooking" og eksporterer/deler formatDate til/med overviewSortBooking */}
        <OverviewSortBooking formatDate={formatDate} />
      </div>
    </div>
  );
}
