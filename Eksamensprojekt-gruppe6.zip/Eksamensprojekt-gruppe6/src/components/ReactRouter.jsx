// React router --> til at skifte indhold på siden 

// Import
import OverviewPage from "./OverviewPage";
import LoginPage from "./LoginPage";
import MyBookingsPage from "./MyBookingsPage";
import { Routes, Route } from "react-router-dom";

export default function Routing() {
  return (
    <div>
      <Routes>

        {/* Forside/Login side */}
        <Route index element={<LoginPage />} />

        {/* Mine bookinger */}
        <Route path="Minebookinger" element={<MyBookingsPage />} /> 

        {/* Oversigt side */}
        <Route path="Nybooking" element={<OverviewPage />} />
      </Routes>
    </div>
  );
}
