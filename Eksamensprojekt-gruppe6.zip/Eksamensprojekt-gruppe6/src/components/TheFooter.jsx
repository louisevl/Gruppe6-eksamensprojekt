// Footer indhold

// Import af ikoner (img mappe)
import linkedin from "./../img/linkedin.png";
import facebook from "./../img/facebook.png";
import insta from "./../img/instagram.png";
import youtube from "./../img/youtube.png";

// Import af css tilhørende footer
import "./../css/TheFooter.css";

// Gør så vi kan eksportere funktionen og bruge den i andre filer 
export default function TheFooter() {
  return (
    <footer>
      <div>
        {/*Linkedin  */}
        <a
          href="https://www.linkedin.com/school/copenhagen-business-academy/?originalSubdomain=dk"
          target="#"
        >
          <img src={linkedin} alt="Linked-in icon" className="socials" />
        </a>

        {/*Facebook  */}
        <a
          href="https://www.facebook.com/copenhagenbusinessacademy/"
          target="#"
        >
          <img src={facebook} alt="Facebook icon" className="socials" />
        </a>

        {/*Instagram */}
        <a
          href="https://www.instagram.com/cphbusiness/?hl=da"
          target="#"
        >
          <img src={insta} alt="Instagram icon" className="socials" />
        </a>

        {/*Youtube*/}
        <a
          href="https://www.youtube.com/user/cphbusiness?app=desktop"
          target="#"
        >
          <img src={youtube} alt="Youtube icon" id="youtubeIcon" />
        </a>
      </div>

      {/*Copyright cph business */}
      <div>
        <p id="copyright">&copy; Cph business</p>
      </div>
    </footer>
  );
}
