//Login-box på login side

//Imports
import { useState } from "react";
import Modal from "react-modal";
import LoginCreateUser from "./LoginCreateUser.jsx";

//Login-indhold
export default function Login() {

  //Til at åbne og lukke modalen
  const [modalIsOpen, setModalIsOpen] = useState(false);

  const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  return (

    //Form med login-elementer
    <form id="userLogin">

          {/* Login overskrift */}
          <h1>Log ind</h1>

          {/* Indtast Email */}
          <div className="inputBox">
          <p className="loginText">Email</p>
          <input
            type="email"
            placeholder="Email"
            required
            minlength="5"
            className="loginInput"
          />
          </div>

          {/* Indtast adgangskode */}
          <div className="inputBox">
          <p className="loginText">Adgangskode</p>
          <input
            type="password"
            placeholder="Adgangskode"
            required
            minlength="8"
            className="loginInput"
          />
          </div>

          {/* Glemt login knap */}
          <p className="loginText">Glemt dit login?</p>

          {/* Login knap */}
          <input type="submit" value="Log ind" id="loginButton" />

          {/* Opret bruger knap og modalbox */}
            <Modal
              isOpen={modalIsOpen}
              onRequestClose={closeModal}
              contentLabel="Create booking form">
              <LoginCreateUser/>
            </Modal>

            <div id="createUserButton">
            <p className="loginText"> Har du ikke en bruger?</p> <br/> <p id="createModal" onClick={openModal}>Opret bruger</p>
            </div>

    </form>
  );
}
