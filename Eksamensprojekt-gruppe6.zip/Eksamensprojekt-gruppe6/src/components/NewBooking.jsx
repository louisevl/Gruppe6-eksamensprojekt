//Denne component indeholder knappen til NewBookingModal

// IMPORT af funktioner, react-modal og component som vi bruger
import { useState } from "react";
import Modal from "react-modal";
import NewBookingModal from "./NewBookingModal.jsx";


export default function NewBooking() {
  //Sætter model til at være closed per default
  const [modalIsOpen, setModalIsOpen] = useState(false);

  //Vi opretter funktioner for at åbne og lukke modalen med 
  const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  return (
    <div>
      {/* Indsætter modal */}
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        contentLabel="Create booking form"
      >
        <NewBookingModal />
      </Modal>
      {/* Vi opretter en button der giver os mulighed for at åbne modalen */}
      <button id="tekst_kalender" onClick={openModal}>
        NY BOOKING
      </button>
    </div>
  );
}
