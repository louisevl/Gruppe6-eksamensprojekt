//Henter kalenderen fra "react-calendar", modificering af funktioner i kalenderen (fx klikke rundt så man kan skifte dato) og dato formattering.

//Import
import { useState, useEffect } from "react";
import Calendar from "react-calendar";
import "./../css/OverviewCalendar.css"

export default function OverviewCalendar({ setFormatDate }) {
  //Konvertere en given dato fra vores kalender, til en string. 
  const [date, setDate] = useState(new Date());
  //Ændrer dato når man klikker på ny dato i kalenderen
  const onDateChange = (newDate) => {
    setDate(newDate);
  }

  //useEffect - Så vi faktisk kan skifte dato.
  useEffect(() => {
    //Ændrer datoen til ønsket format, som i vores tilfælde er YYYY-MM-DD
    setFormatDate(new Intl.DateTimeFormat('sv-SE').format(date));
  },  [date, onDateChange])

  return (
      <div>
        {/* Viser kalenderen*/}
        <Calendar onChange={setDate} value={date} />
      </div>

  );
}
