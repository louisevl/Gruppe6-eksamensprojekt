// Mine bookinger data fra databasen kommer ind
//IMPORT
import trash from "./../img/trashcan.png";
import edit from "./../img/editpen.png";
import { useState, useRef } from "react";
import Modal from "react-modal";
import MyEditBookingModal from "./MyEditBookingModal.jsx";
import Snackbar from "./Snackbar";

//FUNCTION
export default function MyBookingsData({
  //Vi henter vores properties fra MyBookingContent
  id,
  date,
  room,
  time,
  coffee,
  tea,
  message,
  coffeeMessage,
  teaMessage,
}) {
  // DELETE BOOKING
  //Funktion, der sletter en specifik booking
  const postDelete = async () => {
    await fetch(
      "https://eksamen-3-semester-default-rtdb.europe-west1.firebasedatabase.app/" +
        id +
        "/.json",
      {
        method: "DELETE",
      }
    );
    // Vi indsætter vores snackbar
    snackbarRef.current.show();
    setTimeout(function () {
      window.location.reload();
    }, 600);
  };

  // Kaffe og te beskeder - Tilvalg under "Mine Bookinger"
  if (coffee === true) {
    coffeeMessage = "Kaffe";
  }

  if (tea === true) {
    teaMessage = "Te";
  }

  // Modal-metoder til at åbne og lukke vha. arrow functions 
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  //Snackbar bliver defineret
  const snackbarRef = useRef(null);
  const SnackbarType = {
    success: "success",
  };

  return (
    <div className="grid">
      <div className="column"></div>
      {/* Lokale */}
      <div className="column">
        <h5>
          Lokale: <p>{room}</p>
        </h5>
      </div>
      {/* Dato */}
      <div className="column">
        <h5>
          Dato: <p>{date}</p>
        </h5>
      </div>
      {/* Tid */}
      <div className="column">
        <h5>
          Tidsrum: <p>{time}</p>
        </h5>
      </div>
      {/* Bemærkning */}
      <div className="column">
        <h5>
          Evt. bemærkning: <p>{message}</p>
        </h5>
      </div>
      {/* Tilvalg */}
      <div className="column">
        <h5>
          Evt. tilvalg:{" "}
          <p>
            {coffeeMessage} {teaMessage}
          </p>
        </h5>
      </div>

      {/* Edit funktion */}
      <div className="icons">        
        <button onClick={openModal}>
          <img id="edit" src={edit} alt="Rediger" />
        </button>
        
        {/* Delete funktion */}
        <button onClick={postDelete}>
          <img id="trashcan" src={trash} alt="Slet" />
        </button>


        {/* Indsætter component - MyEditBookingModal - som vi bruger højere oppe */}
        <Modal
          isOpen={modalIsOpen}
          onRequestClose={closeModal}
          contentLabel="Create booking form">
          <MyEditBookingModal id={id} />
        </Modal>

        {/* Indsætter component - Snackbar - som vi bruger højere oppe */}
        <Snackbar
          ref={snackbarRef}
          type={SnackbarType.success}
          message="Du har nu slettet din booking"/>

      </div>
      <div className="column"></div>
    </div>
  );
}
