//Snackbar

//Import
import React, { useState, forwardRef, useImperativeHandle } from "react";
import "./../css/Snackbar.css";

//forwardRef - Udspecificerer hvilket element vi gerne vil referere til
const Snackbar = forwardRef((props, ref) => {
  const [showSnackbar, setShowSnackbar] = useState(false);

  //Gør refferancen fra minebookinger tilgængelig
  useImperativeHandle(ref, () => ({
    show() {
        setShowSnackbar(true);
        setTimeout(() => {
        setShowSnackbar(false);
     }, 2000);
    },
  }));
  return (
    <div
      className="snackbar"
      id={showSnackbar ? "show" : "hide"}
      style={{
        // Hvis "success = true" viser den første farve, ellers bliver det næste farve
        backgroundColor: props.type === "success" ? "#CDF5B1" : "#FF0033",
      }}
    >
      {/* Hvis "success = true" viser den først den ene h1, eller bliver det næste h1 */}
      <div className="symbol">
        {props.type === "success" ? <h1>&#x2713;</h1> : <h1>&#x2613;</h1>}
      </div>
      {/* "Message" bliver defineret inde i hver sin copmponent */}
      <div className="message">{props.message}</div>
    </div>
  );
});

export default Snackbar;
