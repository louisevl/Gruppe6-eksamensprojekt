//Hele login siden med box og billede

//Imports af loginbox, css og billede
import LoginContent from "./LoginContent";
import logo from "./../img/cphbusiness.jpg";
import "./../css/LoginPage.css";

export default function LoginPage() {
  return (

      //Div med sideindholdet
      <div id="loginPageContent">

        {/* Indhold fra logincontent, login-boxen */}
        <LoginContent />

        {/* Billede af skolen */}
        <div>
          <img id="loginPicture" src={logo} alt="Picture of people in front of school" />
        </div>
      </div>
  );
}
