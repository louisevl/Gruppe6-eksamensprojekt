// Modalbox hvor man booker en side - til NY BOOKING
//Import
import { useState, useRef } from "react";
import Snackbar from "./Snackbar";

export default function NewBookingModal() {
  // USESTATE
  // Vi bruger usestate til at kunne ændre de forskellige inputs
  const [date, setDate] = useState(""); // Dato
  const [time, setTime] = useState(""); // Tid
  const [room, setRoom] = useState(""); // Mødelokale
  const [message, setMessage] = useState(""); // Besked
  const [coffee, setCoffee] = useState(false); // Kaffe-tilvalg - skal være false da den ellers er tom.
  const [tea, setTea] = useState(false); // Te-tilvalg

  // HANDLE INPUTS
  // Vi skal lave en handle til hvert input så man kan ændre deres value.

  const handleDate = (event) => {
    setDate(event.target.value);
  };

  const handleTime = (event) => {
    setTime(event.target.value);
  };

  const handleRoom = (event) => {
    setRoom(event.target.value);
  };

  const handleCoffee = () => {
    setCoffee((current) => !current);
  };

  const handleTea = () => {
    setTea((current) => !current);
  };

  const handleMessage = (event) => {
    setMessage(event.target.value);
  };

  //Snackbar bliver defineret
  const snackbarRef = useRef(null);
  const SnackbarType = {
    success: "success",
  };



  // HANDLE SUBMIT
  // Vi bruger handleSubmit til at sende vores data til databasen.
  const handleSubmit = async (event) => {
    event.preventDefault()
    if (!date || !time || !room){

    } else {
      //Definere variablerne til kaffe og te
      const coffeeMessage = "";
      const teaMessage = "";

      //Vi laver et objekt som indeholder alt dataen som vi skal sende videre til vores DB.
      let booking = {

        date: date,
        time: time,
        room: room,
        coffee: coffee,
        tea: tea,
        message: message,
        coffeeMessage: coffeeMessage,
        teaMessage: teaMessage,
      };

      //Vi opretter connection til vores database med metoden post, så vi kan tilføje den givne data til den.
      await fetch(
        "https://eksamen-3-semester-default-rtdb.europe-west1.firebasedatabase.app/.json",
        {
          method: "POST",
          body: JSON.stringify(booking),
        }
      );

      //Vi viser vores snackbar
      snackbarRef.current.show();

      //Automatisk reload af siden efter XXX antal ms
      setTimeout(function () {
        window.location.reload();
      }, 1200);
    }
    
  };

  return (
    <form className="bookingform" onSubmit={handleSubmit}>
      <div className="modalbox">
        {/* Trin bokse */}
        <div className="outerbox">
          {/* Trin 1 Date */}
          <div className="stepbox">
            <h2>Trin 1</h2>
            {/* DATO */}
            <label className="stepTitle">Dato</label>
            <input
              type="date"
              placeholder="Dato - f.eks. 15-10-2022"
              name="date"
              value={date}
              onChange={handleDate}
              id="bookingCalendar"
              required
            />
          </div>
          {/* Trin 2 Time */}
          <div className="stepbox">
            {/* TIDSPUNKT */}
            <div value={time}>
              <h2>Trin 2</h2>
              <label className="stepTitle">Vælg tidspunkt</label>
              <br />
              <input
                type="radio"
                id="morning"
                value="8:30-12:00"
                onChange={handleTime}
                name="chooseTime"
                required                
              />
              <label htmlFor="morning">Morgen 8:30-12:00</label>
              <br />

              <input
                type="radio"
                id="afternoon"
                value="12:30-16:00"
                onChange={handleTime}
                name="chooseTime"

              />
              <label htmlFor="afternoon">Eftermiddag 12:30-16:00</label>
            </div>
          </div>

          {/* Trin 3 Lokale */}
          <div className="stepbox">
            <h2>Trin 3</h2>
            <label htmlFor="lokaledropdown" className="stepTitle">
              Lokale
            </label>
            <select
              onChange={handleRoom}
              name="lokaledropdown"
              id="lokaledropdown"
              value={room}
              required
            >
              <option value="">Vælg et lokale:</option>
              <option value="1">1</option>

              <option value="2">2</option>

              <option value="3">3</option>

              <option value="4">4</option>

              <option value="5">5</option>

              <option value="6">6</option>

              <option value="7">7</option>
            </select>
          </div>
        </div>
        <div className="outerbox">
          {/* Trin 4 Vælg tilvalg */}
          <div className="stepbox">
            <h2>Trin 4</h2>
            <label className="stepTitle">Tilvalg:</label>

            {/* Kaffe */}
            <div id="checkbox">
              <input
                type="checkbox"
                id="coffee"
                name="coffee"
                value={coffee}
                onChange={handleCoffee}
              />
              <label htmlFor="coffee">Kaffe</label>
            </div>

            {/* Te */}
            <div id="checkbox">
              <input
                type="checkbox"
                id="tea"
                name="tea"
                value={tea}
                onChange={handleTea}
              />
              <label htmlFor="tea">Te</label>
            </div>
          </div>

          {/* Trin 5 Indtast felt */}
          <div className="stepbox">
            <h2>Trin 5</h2>
            <label className="stepTitle">Beskrivelse</label>
            <textarea
              onChange={handleMessage}
              input="text"
              name=""
              id=""
              cols="10"
              rows="5"
            ></textarea>
          </div>

          {/*Trin 6 Bekræft og book*/}
          <div className="stepbox">
            <h2>Trin 6</h2>
            <label className="stepTitle">Bekræft</label>
            {/* Indsæt values */}
            <input
              id="bookbutton"
              className="showSnackbarBttn"
              type="submit"
              value="Book"
            />
  
            {/* Indsætter component - Snackbar - som vi bruger højere oppe */}
            <Snackbar
              ref={snackbarRef}
              type={SnackbarType.success}
              message="Tillykke! Du har nu oprettet en booking"
            />
          </div>
        </div>
      </div>
    </form>
  );
}
