// Henter dataen til aktuelle bookinger

// Importere
import { useEffect, useState } from "react";
import { transformToArray } from "../firebase-utils";
import OverviewBooking from "./OverviewBooking";

export default function OverviewSortBooking({formatDate}) {
    const [bookings, setBookings] = useState([]);
    // Henter data og formaterer fra json til array
    useEffect(() => {
        //opretter en asynkron funktion.
        async function getData() {
            const response = await fetch("https://eksamen-3-semester-default-rtdb.europe-west1.firebasedatabase.app/.json");
            const body = await response.json();
            const asArray = transformToArray(body);
            setBookings(asArray);
        }
        getData();
    }, []);

    return (
        <div>
            {/* Overskrift */}
            <h1 id="bookings">Bookinger</h1>

            {/*Viser de forskellige bookinger, på den givne dato der er klikket på i kalenderen*/}
            {bookings.filter(bookings => bookings.date.includes(formatDate)).map((booking) => {
                return <OverviewBooking formatDate={formatDate} date={booking.date} room={booking.room} time={booking.time} id={booking.id} />;
            })}
        </div>
    );

}

