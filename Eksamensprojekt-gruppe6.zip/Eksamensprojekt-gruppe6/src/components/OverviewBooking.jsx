// Funktion der viser bookingerne på oversigt-siden, OverviewPage.jsx (Til højre for kalenderen).
export default function OverviewBooking({date, room, time}) {
  return (
    <div className="showbookings">
      <div className="element">
        {/*Sørger for at klasselokalet bliver vist*/}
        <p className="overviewFont">Klasselokale: {room}</p>
      </div>
    
      <div className="element">
        {/*Sørger for at dato bliver vist*/}
        <p className="overviewFont">Dato: {date}</p>
      </div>
    
      <div className="element">
        {/*Sørger for at tidspunkt for booking bliver vist*/}
        <p className="overviewFont"> Tid: {time}</p>
      </div>
    </div>
  );
}
  
