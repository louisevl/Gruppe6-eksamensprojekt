// Tager imod data fra MyBookingsData
//IMPORT
import { useEffect, useState } from "react";
import { transformToArray } from "../firebase-utils";
import MyBookingsData from "./MyBookingsData";

//FUNCTION
export default function MyBookingsContent() {
  
  const [bookings, setBookings] = useState([]);

  // Henter data og formaterer fra json til array
  useEffect(() => {
    async function getData() {
      const response = await fetch("https://eksamen-3-semester-default-rtdb.europe-west1.firebasedatabase.app/.json");
      const body = await response.json();
      const asArray = transformToArray(body);
      setBookings(asArray);
    }
    getData();
  }, []);

  return (
    <div className="bookingContent">
      <h1 id="myBookings">Mine Bookinger</h1>
      {/* Vi tager alle elementer i bookings og laver om til enkelte objekter */}
      {bookings.map((booking) => {
        return (
          //Sender de enkelte elementer i vores data, så de kan blive brugt i "MyBookingsData"
          <MyBookingsData
            date={booking.date}
            room={booking.room}
            time={booking.time}
            id={booking.id}
            tea={booking.tea}
            coffee={booking.coffee}
            message={booking.message}
            coffeeMessage={booking.coffeeMessage}
            teaMessage={booking.teaMessage}
          />
        );
      })};
    </div>
  );
};