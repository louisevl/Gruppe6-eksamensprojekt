//Opret en bruger i databasen side 

//Import
import { useState } from "react";

export default function LoginCreateUser() {

  //Usestate til at sætte email og password
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  //Sæt værdierne fra inputfelterne
  const handleEmail = (event) => {
    setEmail(event.target.value);
  };
  const handlePassword = (event) => {
    setPassword(event.target.value);
  };

  const handleSignup = async (event) => {
    event.preventDefault();

    // Fetch til database
    await fetch(
      "https://eksamen-3-semester-login-default-rtdb.europe-west1.firebasedatabase.app/.json",
      {
        method: "POST",
        body: JSON.stringify({
          email: email,
          password: password,
        }),
      }
    );

    //Window reload når man har oprettet en bruger
    setTimeout(function () {
      window.location.reload();
    }, 1200);
  };

  return (
    //Opret bruger box
    <form id="createUser"  onSubmit={handleSignup}>
      <h1>Opret bruger</h1>

      {/* Email */}
      <div className="inputBox">
      <p>Email</p>
      <input
        type="email"
        placeholder="Email"
        required
        minlength="5"
        className="createInput"
        onChange={handleEmail}
        value={email}
      />
      </div>

      <div className="inputBox">
      <p>Gentag email</p>
      <input
        type="email"
        placeholder="Gentag email"
        required
        className="verify"
      />
      </div>

      {/* Adgangskode */}
      <div className="inputBox">
      <p>Adgangskode</p>
      <input
        type="password"
        placeholder="Adgangskode"
        required
        minlength="8"
        className="createInput"
        value={password}
        onChange={handlePassword}
      />
      </div>
      <div className="inputBox">
      <p>Gentag adgangskode</p>
      <input
        type="password"
        placeholder="Gentag adgangskode"
        required
        className="verify"
      />
      </div>

      {/* Knap */}
      <input type="submit" value="Opret bruger" id="createButton"/>
    </form>
  );
}
