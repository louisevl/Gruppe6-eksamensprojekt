//Mine bookinger side - inderholder content fra MyBookingContent som får data fra databasen

//IMPORT
import MyBookingsContent from "./MyBookingsContent";
import "./../css/MyBookingsPage.css";

//FUNCTION
//Vi indsætter vores content så det bliver vist på siden
export default function MyBookingsPage() {
  return (
      <MyBookingsContent />
  );
};
