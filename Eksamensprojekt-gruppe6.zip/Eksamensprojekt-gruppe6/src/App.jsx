// PARENT-COMPONENT - der holder alle dokumenterne
// IMPORT
import TheHeader from "./components/TheHeader";
import TheFooter from "./components/TheFooter";
import { useState } from "react";
import { BrowserRouter } from "react-router-dom";
import Routing from "./components/ReactRouter";
import Modal from "react-modal";
Modal.setAppElement("#root");

// FUNCTION
export default function App() {
    //Opretter tomt array (bookings) og dertilhørende funktion setBookings
  const [bookings, setBookings] = useState([]);

  return (
    <div className="App">
      {/* BrowserRouter indeholder nuværende side i http adressen */}
      <BrowserRouter basename="/louisevl/tilUX">
        {/* Header */}
        <TheHeader setBookings={setBookings} />
        {/* Henter vores Routing element, som skifter indhold på siden */}
        <Routing />
        {/* Footer */}
        <TheFooter bookings={bookings} setBookings={setBookings} />
      </BrowserRouter>
    </div>
  );
}
