const person = {name: 'Kanza', email: 'kanza@kanza.dk'};

// const email2 = person.email;
// const name2 = person.name;   

// destructuring variabler =  objektet
const {name, email}       = person; 

console.log(name);
console.log(email);